package com.ironmanmod;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameRules;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = IronManMod.MODID)
public class ServerEvents {

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase == TickEvent.Phase.END && e.side == LogicalSide.SERVER && e.player instanceof ServerPlayer sp) {
            SuitData.tick(sp);
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) SuitData.sync(sp);
    }

    /** L'armatura annulla i danni da caduta. */
    @SubscribeEvent
    public static void onFall(LivingFallEvent e) {
        if (e.getEntity() instanceof Player p && SuitData.activeMark(p) != null) e.setCanceled(true);
    }

    /** Scudo nanotech: assorbe parte del danno consumando energia. */
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        SuitMark m = SuitData.activeMark(p);
        if (m == null || m.shield <= 0f) return;
        if (e.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return;
        float amt = e.getAmount();
        if (SuitData.useEnergy(p, (int) (amt * 20))) e.setAmount(amt * (1.0f - m.shield));
    }

    /** I pezzi dell'armatura non si possono lanciare a terra. */
    @SubscribeEvent
    public static void onToss(ItemTossEvent e) {
        if (SuitData.isSuit(e.getEntity().getItem())) e.setCanceled(true);
    }

    /** Alla morte l'armatura nanotech sparisce: droppano l'armatura originale e le gemme. */
    @SubscribeEvent
    public static void onDrops(LivingDropsEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        if (p.level().getGameRules().getBoolean(GameRules.RULE_KEEPINVENTORY)) return;

        e.getDrops().removeIf(it -> SuitData.isSuit(it.getItem()));

        CompoundTag r = SuitData.root(p);
        for (Tag t : r.getList("orig", Tag.TAG_COMPOUND)) {
            ItemStack s = ItemStack.of((CompoundTag) t);
            if (!s.isEmpty()) e.getDrops().add(new ItemEntity(p.level(), p.getX(), p.getY(), p.getZ(), s));
        }
        for (Tag t : r.getList("gems", Tag.TAG_COMPOUND)) {
            ItemStack s = ItemStack.of((CompoundTag) t);
            if (!s.isEmpty()) e.getDrops().add(new ItemEntity(p.level(), p.getX(), p.getY(), p.getZ(), s));
        }
        r.remove("orig");
        r.remove("gems");
        r.putInt("active", 0);
        r.putInt("phase", 0);
        r.putInt("t", 0);
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        Player o = e.getOriginal();
        Player n = e.getEntity();
        CompoundTag or = SuitData.root(o);

        if (!e.isWasDeath()) { // cambio dimensione ecc.: si porta dietro tutto
            n.getPersistentData().put(SuitData.ROOT, or.copy());
            return;
        }
        CompoundTag nr = SuitData.root(n);
        if (or.contains("selected")) nr.putInt("selected", or.getInt("selected"));

        if (n.level().getGameRules().getBoolean(GameRules.RULE_KEEPINVENTORY)) {
            // l'inventario e' stato copiato con i pezzi nanotech dentro: toglili e rimetti l'armatura originale
            if (or.contains("gems")) {
                ListTag gems = or.getList("gems", Tag.TAG_COMPOUND).copy();
                nr.put("gems", gems);
            }
            if (or.contains("energy")) nr.putInt("energy", or.getInt("energy"));
            SuitData.restoreOriginals(n, or);
        }
    }
}
