package com.ironmanmod;

import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** Pannello della Mark 85: 1 slot Nucleo (mod esterna) + 6 slot Gemme. */
public class GemMenu extends AbstractContainerMenu {
    public static final int SLOTS = 7;

    public GemMenu(int id, Inventory inv, Container gems) {
        super(IronManMod.GEM_MENU.get(), id);
        checkContainerSize(gems, SLOTS);

        addSlot(new GemSlot(gems, 0, 8, 28, true));
        for (int i = 0; i < 6; i++) {
            addSlot(new GemSlot(gems, i + 1, 44 + i * 18, 28, false));
        }
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inv, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inv, col, 8 + col * 18, 142));
        }
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            result = stack.copy();
            if (index < SLOTS) {
                if (!moveItemStackTo(stack, SLOTS, slots.size(), true)) return ItemStack.EMPTY;
            } else if (!moveItemStackTo(stack, 0, SLOTS, false)) {
                return ItemStack.EMPTY;
            }
            if (stack.isEmpty()) slot.setByPlayer(ItemStack.EMPTY);
            else slot.setChanged();
        }
        return result;
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }

    private static class GemSlot extends Slot {
        private final boolean core;

        GemSlot(Container c, int index, int x, int y, boolean core) {
            super(c, index, x, y);
            this.core = core;
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return core ? GemRules.isCore(stack) : GemRules.gemIndex(stack) >= 0;
        }

        @Override
        public int getMaxStackSize() {
            return 1;
        }
    }
}
