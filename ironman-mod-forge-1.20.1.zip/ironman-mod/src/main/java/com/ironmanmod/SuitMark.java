package com.ironmanmod;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

/** I tre modelli di armatura. Funge anche da materiale armatura. */
public enum SuitMark implements ArmorMaterial {
    //        num  id       energia  volo    boost  repuls. unibeam missili scudo  difesa(boots,legs,chest,helm)  tough kb
    MARK_42(42, "mark42", 2000, 0.065f, 1.4, 8f, 0f, 4, 0.00f, new int[]{3, 6, 7, 3}, 2.0f, 0.0f),
    MARK_50(50, "mark50", 4500, 0.085f, 2.0, 11f, 28f, 6, 0.20f, new int[]{4, 8, 9, 4}, 3.0f, 0.1f),
    MARK_85(85, "mark85", 9000, 0.110f, 2.6, 14f, 40f, 8, 0.35f, new int[]{5, 9, 12, 5}, 4.5f, 0.2f);

    public final int number;
    public final String id;
    public final int maxEnergy;
    public final float flySpeed;
    public final double boost;
    public final float repulsorDamage;
    public final float unibeamDamage;
    public final int missiles;
    public final float shield;
    private final int[] defense;
    private final float toughness;
    private final float knockback;

    SuitMark(int number, String id, int maxEnergy, float flySpeed, double boost, float repulsorDamage,
             float unibeamDamage, int missiles, float shield, int[] defense, float toughness, float knockback) {
        this.number = number;
        this.id = id;
        this.maxEnergy = maxEnergy;
        this.flySpeed = flySpeed;
        this.boost = boost;
        this.repulsorDamage = repulsorDamage;
        this.unibeamDamage = unibeamDamage;
        this.missiles = missiles;
        this.shield = shield;
        this.defense = defense;
        this.toughness = toughness;
        this.knockback = knockback;
    }

    public static SuitMark byNumber(int n) {
        for (SuitMark m : values()) {
            if (m.number == n) return m;
        }
        return null;
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        return 9999;
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return switch (type) {
            case BOOTS -> defense[0];
            case LEGGINGS -> defense[1];
            case CHESTPLATE -> defense[2];
            case HELMET -> defense[3];
        };
    }

    @Override
    public int getEnchantmentValue() {
        return 0;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ARMOR_EQUIP_NETHERITE;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.EMPTY;
    }

    @Override
    public String getName() {
        return IronManMod.MODID + ":" + id;
    }

    @Override
    public float getToughness() {
        return toughness;
    }

    @Override
    public float getKnockbackResistance() {
        return knockback;
    }
}
