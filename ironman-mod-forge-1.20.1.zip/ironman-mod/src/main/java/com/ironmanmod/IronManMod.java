package com.ironmanmod;

import com.ironmanmod.net.Net;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafml.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

@Mod(IronManMod.MODID)
public class IronManMod {
    public static final String MODID = "ironmanmod";

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(ForgeRegistries.MENU_TYPES, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final Map<SuitMark, Map<ArmorItem.Type, RegistryObject<Item>>> ARMOR = new EnumMap<>(SuitMark.class);
    public static final Map<SuitMark, RegistryObject<Item>> REACTORS = new EnumMap<>(SuitMark.class);
    public static final List<RegistryObject<Item>> GEMS = new ArrayList<>();

    static {
        for (SuitMark m : SuitMark.values()) {
            Map<ArmorItem.Type, RegistryObject<Item>> pieces = new EnumMap<>(ArmorItem.Type.class);
            for (ArmorItem.Type t : ArmorItem.Type.values()) {
                pieces.put(t, ITEMS.register(m.id + "_" + t.getName(), () -> new SuitArmorItem(m, t)));
            }
            ARMOR.put(m, pieces);
            REACTORS.put(m, ITEMS.register("arc_reactor_" + m.id,
                    () -> new Item(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC))));
        }
        for (String k : GemRules.KEYS) {
            GEMS.add(ITEMS.register("gem_" + k,
                    () -> new Item(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant())));
        }
    }

    public static final RegistryObject<MenuType<GemMenu>> GEM_MENU = MENUS.register("gem_menu",
            () -> IForgeMenuType.create((id, inv, buf) -> new GemMenu(id, inv, new SimpleContainer(GemMenu.SLOTS))));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.ironmanmod"))
                    .icon(() -> new ItemStack(REACTORS.get(SuitMark.MARK_85).get()))
                    .displayItems((params, out) -> {
                        for (SuitMark m : SuitMark.values()) out.accept(REACTORS.get(m).get());
                        for (RegistryObject<Item> g : GEMS) out.accept(g.get());
                    })
                    .build());

    public IronManMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        MENUS.register(bus);
        TABS.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
        bus.addListener((FMLCommonSetupEvent e) -> e.enqueueWork(Net::init));
    }
}
