package com.ironmanmod;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.List;

/** File: config/ironmanmod-common.toml */
public final class Config {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue TRANSFORM_TICKS;
    public static final ForgeConfigSpec.BooleanValue REQUIRE_REACTOR;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> EXTERNAL_MOD_IDS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        TRANSFORM_TICKS = b.comment("Durata della trasformazione nanotech in tick (20 tick = 1 secondo). Default 60 = 3 secondi.")
                .defineInRange("transformTicks", 60, 20, 400);

        REQUIRE_REACTOR = b.comment("Se true serve avere il Reattore Arc del modello nell'inventario per trasformarsi.")
                .define("requireReactor", true);

        EXTERNAL_MOD_IDS = b.comment(
                        "ID delle mod esterne con le Gemme dell'Infinito / il Nucleo (es. Pugmeowla's Infinity Stone Core).",
                        "Se una di queste mod e' installata, nel pannello della Mark 85 lo slot Nucleo accetta i suoi item",
                        "e le sue gemme (il cui nome contiene power/space/reality/soul/time/mind) valgono come gemme.",
                        "Se la tua mod ha un ID diverso, aggiungilo qui (lo vedi in schermata Mods, o col comando /give <item> in chat).")
                .defineListAllowEmpty("externalModIds",
                        List.of("infinity_stone_core", "infinitystonecore", "infinity_stones", "infinity_gems",
                                "infinitygems", "pugmeowla_infinity_stone_core", "infinity_core"),
                        o -> o instanceof String);

        SPEC = b.build();
    }

    private Config() {
    }
}
