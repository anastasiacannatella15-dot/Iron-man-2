package com.ironmanmod.client;

import com.ironmanmod.IronManMod;
import com.ironmanmod.SuitMark;
import com.ironmanmod.net.Net;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = IronManMod.MODID, value = Dist.CLIENT)
public class ClientForgeBus {

    private static void poll(KeyMapping key, int action, boolean canSend) {
        while (key.consumeClick()) {
            if (canSend) Net.sendAction(action);
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        boolean can = mc.screen == null;
        poll(ClientModBus.TRANSFORM, Net.A_TRANSFORM, can);
        poll(ClientModBus.CYCLE, Net.A_CYCLE, can);
        poll(ClientModBus.REPULSOR, Net.A_REPULSOR, can);
        poll(ClientModBus.UNIBEAM, Net.A_UNIBEAM, can);
        poll(ClientModBus.MISSILES, Net.A_MISSILES, can);
        poll(ClientModBus.SPACE, Net.A_SPACE, can);
        poll(ClientModBus.PANEL, Net.A_PANEL, can);

        // Volo veloce: sprint + avanti mentre voli = spinta nella direzione in cui guardi
        SuitMark m = ClientState.activeMark();
        if (can && m != null && ClientState.energy > 0
                && mc.player.getAbilities().flying
                && mc.options.keySprint.isDown() && mc.options.keyUp.isDown()) {
            mc.player.setSprinting(true);
            Vec3 look = mc.player.getLookAngle();
            mc.player.setDeltaMovement(look.scale(m.boost));
        }
    }
}
