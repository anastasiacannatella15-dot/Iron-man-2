package com.ironmanmod.client;

import com.ironmanmod.IronManMod;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = IronManMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModBus {
    private static final String CAT = "key.categories.ironmanmod";

    public static final KeyMapping TRANSFORM = new KeyMapping("key.ironmanmod.transform", InputConstants.KEY_G, CAT);
    public static final KeyMapping CYCLE = new KeyMapping("key.ironmanmod.cycle", InputConstants.KEY_H, CAT);
    public static final KeyMapping REPULSOR = new KeyMapping("key.ironmanmod.repulsor", InputConstants.KEY_R, CAT);
    public static final KeyMapping UNIBEAM = new KeyMapping("key.ironmanmod.unibeam", InputConstants.KEY_V, CAT);
    public static final KeyMapping MISSILES = new KeyMapping("key.ironmanmod.missiles", InputConstants.KEY_B, CAT);
    public static final KeyMapping SPACE = new KeyMapping("key.ironmanmod.space", InputConstants.KEY_X, CAT);
    public static final KeyMapping PANEL = new KeyMapping("key.ironmanmod.panel", InputConstants.KEY_K, CAT);

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(TRANSFORM);
        e.register(CYCLE);
        e.register(REPULSOR);
        e.register(UNIBEAM);
        e.register(MISSILES);
        e.register(SPACE);
        e.register(PANEL);
    }

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("ironman_hud", ClientHud::render);
    }

    @SubscribeEvent
    public static void clientSetup(FMLClientSetupEvent e) {
        e.enqueueWork(() -> MenuScreens.register(IronManMod.GEM_MENU.get(), GemScreen::new));
    }
}
