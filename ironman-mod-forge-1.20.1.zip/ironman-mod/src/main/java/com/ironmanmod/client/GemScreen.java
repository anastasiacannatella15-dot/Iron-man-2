package com.ironmanmod.client;

import com.ironmanmod.GemMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

/** Pannello Mark 85: slot Nucleo + 6 gemme. Disegnato via codice, nessuna texture richiesta. */
public class GemScreen extends AbstractContainerScreen<GemMenu> {

    public GemScreen(GemMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 176;
        this.imageHeight = 166;
        this.inventoryLabelY = 73;
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x = leftPos, y = topPos;
        g.fill(x, y, x + imageWidth, y + imageHeight, 0xEE0A1018);
        // bordo azzurro
        g.fill(x, y, x + imageWidth, y + 1, 0xFF00C8FF);
        g.fill(x, y + imageHeight - 1, x + imageWidth, y + imageHeight, 0xFF00C8FF);
        g.fill(x, y, x + 1, y + imageHeight, 0xFF00C8FF);
        g.fill(x + imageWidth - 1, y, x + imageWidth, y + imageHeight, 0xFF00C8FF);

        for (Slot s : menu.slots) {
            boolean special = s.index < GemMenu.SLOTS;
            int frame = special ? (s.index == 0 ? 0xFFFFC000 : 0xFF00C8FF) : 0xFF000000;
            g.fill(x + s.x - 1, y + s.y - 1, x + s.x + 17, y + s.y + 17, frame);
            g.fill(x + s.x, y + s.y, x + s.x + 16, y + s.y + 16, 0xFF1E2A38);
        }
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        g.drawString(font, title, 8, 6, 0x66E0FF, false);
        g.drawString(font, Component.translatable("gui.ironmanmod.core"), 8, 18, 0xFFC000, false);
        g.drawString(font, Component.translatable("gui.ironmanmod.gemslots"), 44, 18, 0x66E0FF, false);
        g.drawString(font, playerInventoryTitle, 8, inventoryLabelY, 0xA0A0A0, false);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        super.render(g, mouseX, mouseY, partialTick);
        renderTooltip(g, mouseX, mouseY);
    }
}
