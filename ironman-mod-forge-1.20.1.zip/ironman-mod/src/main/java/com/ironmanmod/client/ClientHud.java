package com.ironmanmod.client;

import com.ironmanmod.IronManMod;
import com.ironmanmod.SuitMark;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/** HUD: bottone di trasformazione in alto a sinistra, slot Nucleo/Gemme in alto a destra, telemetria "FRIDAY". */
public final class ClientHud {
    private ClientHud() {
    }

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        boolean showButton = ClientState.active > 0 || ClientState.owned != 0 || mc.player.isCreative();
        if (!showButton) return;

        Font f = mc.font;
        SuitMark mk = SuitMark.byNumber(ClientState.active > 0 ? ClientState.active : ClientState.selected);
        if (mk == null) mk = SuitMark.MARK_42;
        boolean busy = ClientState.phase != 0;
        boolean on = ClientState.active > 0;

        // ---------- bottone in alto a sinistra
        int x = 6, y = 6, bw = 158, bh = 22;
        int border = busy ? 0xFFFFC000 : (on ? 0xFF00E5FF : 0xFFFF3030);
        g.fill(x - 1, y - 1, x + bw + 1, y + bh + 1, border);
        g.fill(x, y, x + bw, y + bh, 0xD00A1018);
        g.renderItem(new ItemStack(IronManMod.REACTORS.get(mk).get()), x + 3, y + 3);

        Component key = ClientModBus.TRANSFORM.getTranslatedKeyMessage();
        Component label;
        if (busy) {
            int pct = Math.min(100, ClientState.t * 100 / ClientState.dur);
            label = Component.translatable(ClientState.phase == 1 ? "hud.ironmanmod.forming" : "hud.ironmanmod.removing", pct);
        } else if (on) {
            label = Component.translatable("hud.ironmanmod.remove", key);
        } else {
            label = Component.translatable("hud.ironmanmod.transform", key, mk.number);
        }
        g.drawString(f, label, x + 24, y + 7, 0xFFFFFF, true);

        // barra progresso trasformazione / barra energia
        if (busy) {
            float frac = Math.min(1f, ClientState.t / (float) ClientState.dur);
            g.fill(x, y + bh + 3, x + bw, y + bh + 8, 0xFF000000);
            g.fill(x + 1, y + bh + 4, x + 1 + (int) ((bw - 2) * frac), y + bh + 7, 0xFFFFC000);
        } else if (on) {
            float frac = Math.min(1f, ClientState.energy / (float) ClientState.maxEnergy);
            int color = frac > 0.25f ? 0xFF00D8FF : 0xFFFF3030;
            g.fill(x, y + bh + 3, x + bw, y + bh + 8, 0xFF000000);
            g.fill(x + 1, y + bh + 4, x + 1 + (int) ((bw - 2) * frac), y + bh + 7, color);
            g.drawString(f, Component.translatable("hud.ironmanmod.energy", (int) (frac * 100)), x, y + bh + 11, 0x66E0FF, true);

            Vec3 v = mc.player.getDeltaMovement();
            double speed = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z) * 20.0;
            g.drawString(f, Component.translatable("hud.ironmanmod.telemetry", (int) mc.player.getY(), (int) speed),
                    x, y + bh + 22, 0x66E0FF, true);
        }

        // ---------- slot Nucleo + Gemme in alto a destra (Mark 85)
        boolean anyStack = false;
        for (ItemStack s : ClientState.stacks) if (!s.isEmpty()) anyStack = true;
        if (ClientState.activeMark() == SuitMark.MARK_85 && (ClientState.external || anyStack)) {
            int sx = w - 26;
            int sy = 6;
            slot(g, sx, sy, ClientState.stacks[0], 0xFFFFC000); // Nucleo
            for (int i = 1; i <= 6; i++) {
                slot(g, sx, sy + 4 + i * 20, ClientState.stacks[i], 0xFF00E5FF);
            }
            Component hint = Component.translatable("hud.ironmanmod.panel", ClientModBus.PANEL.getTranslatedKeyMessage());
            g.drawString(f, hint, sx + 18 - f.width(hint), sy + 4 + 7 * 20 + 2, 0xCCCCCC, true);
        }
    }

    private static void slot(GuiGraphics g, int x, int y, ItemStack stack, int border) {
        g.fill(x - 1, y - 1, x + 19, y + 19, border);
        g.fill(x, y, x + 18, y + 18, 0xD00A1018);
        if (!stack.isEmpty()) g.renderItem(stack, x + 1, y + 1);
    }
}
