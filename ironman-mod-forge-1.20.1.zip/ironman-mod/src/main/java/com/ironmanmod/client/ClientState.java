package com.ironmanmod.client;

import com.ironmanmod.SuitMark;
import com.ironmanmod.net.Net;
import net.minecraft.world.item.ItemStack;

import java.util.Arrays;

/** Copia lato client dello stato dell'armatura (arriva dal server ogni mezzo secondo). */
public final class ClientState {
    public static int active;
    public static int selected = 42;
    public static int phase;
    public static int t;
    public static int dur = 60;
    public static int energy;
    public static int maxEnergy = 1;
    public static int owned;
    public static boolean external;
    public static final ItemStack[] stacks = new ItemStack[7];

    static {
        Arrays.fill(stacks, ItemStack.EMPTY);
    }

    private ClientState() {
    }

    public static void apply(Net.SyncPacket p) {
        active = p.active;
        selected = p.selected;
        phase = p.phase;
        t = p.t;
        dur = Math.max(1, p.dur);
        energy = p.energy;
        maxEnergy = Math.max(1, p.maxEnergy);
        owned = p.owned;
        external = p.external;
        System.arraycopy(p.stacks, 0, stacks, 0, 7);
    }

    public static SuitMark activeMark() {
        return phase == 0 && active > 0 ? SuitMark.byNumber(active) : null;
    }
}
