package com.ironmanmod.net;

import com.ironmanmod.IronManMod;
import com.ironmanmod.SuitData;
import com.ironmanmod.client.ClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public final class Net {
    public static final int A_TRANSFORM = 0;
    public static final int A_CYCLE = 1;
    public static final int A_REPULSOR = 2;
    public static final int A_UNIBEAM = 3;
    public static final int A_MISSILES = 4;
    public static final int A_SPACE = 5;
    public static final int A_PANEL = 6;

    private static final String PROTOCOL = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(IronManMod.MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private Net() {
    }

    public static void init() {
        int id = 0;
        CH.registerMessage(id++, ActionPacket.class, ActionPacket::encode, ActionPacket::decode, ActionPacket::handle);
        CH.registerMessage(id++, SyncPacket.class, SyncPacket::encode, SyncPacket::decode, SyncPacket::handle);
    }

    public static void sendAction(int action) {
        CH.sendToServer(new ActionPacket(action));
    }

    /** Client -> server: un tasto premuto. */
    public static class ActionPacket {
        public final int action;

        public ActionPacket(int action) {
            this.action = action;
        }

        public void encode(FriendlyByteBuf buf) {
            buf.writeVarInt(action);
        }

        public static ActionPacket decode(FriendlyByteBuf buf) {
            return new ActionPacket(buf.readVarInt());
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            NetworkEvent.Context c = ctx.get();
            c.enqueueWork(() -> {
                ServerPlayer sp = c.getSender();
                if (sp != null) SuitData.handleAction(sp, action);
            });
            c.setPacketHandled(true);
        }
    }

    /** Server -> client: stato dell'armatura per l'HUD. */
    public static class SyncPacket {
        public final int active, selected, phase, t, dur, energy, maxEnergy, owned;
        public final boolean external;
        public final ItemStack[] stacks;

        public SyncPacket(int active, int selected, int phase, int t, int dur, int energy, int maxEnergy,
                          int owned, boolean external, ItemStack[] stacks) {
            this.active = active;
            this.selected = selected;
            this.phase = phase;
            this.t = t;
            this.dur = dur;
            this.energy = energy;
            this.maxEnergy = maxEnergy;
            this.owned = owned;
            this.external = external;
            this.stacks = stacks;
        }

        public void encode(FriendlyByteBuf buf) {
            buf.writeVarInt(active);
            buf.writeVarInt(selected);
            buf.writeVarInt(phase);
            buf.writeVarInt(t);
            buf.writeVarInt(dur);
            buf.writeVarInt(energy);
            buf.writeVarInt(maxEnergy);
            buf.writeVarInt(owned);
            buf.writeBoolean(external);
            for (int i = 0; i < 7; i++) buf.writeItem(stacks[i]);
        }

        public static SyncPacket decode(FriendlyByteBuf buf) {
            int active = buf.readVarInt();
            int selected = buf.readVarInt();
            int phase = buf.readVarInt();
            int t = buf.readVarInt();
            int dur = buf.readVarInt();
            int energy = buf.readVarInt();
            int maxEnergy = buf.readVarInt();
            int owned = buf.readVarInt();
            boolean external = buf.readBoolean();
            ItemStack[] st = new ItemStack[7];
            for (int i = 0; i < 7; i++) st[i] = buf.readItem();
            return new SyncPacket(active, selected, phase, t, dur, energy, maxEnergy, owned, external, st);
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            NetworkEvent.Context c = ctx.get();
            c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientState.apply(this)));
            c.setPacketHandled(true);
        }
    }
}
