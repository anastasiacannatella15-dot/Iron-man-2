package com.ironmanmod;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.registries.ForgeRegistries;

/** Riconosce le gemme (nostre o di una mod esterna) e il "Nucleo". */
public final class GemRules {
    /** Ordine fisso: 0 potere, 1 spazio, 2 realta', 3 anima, 4 tempo, 5 mente. */
    public static final String[] KEYS = {"power", "space", "reality", "soul", "time", "mind"};

    private GemRules() {
    }

    public static boolean externalPresent() {
        for (String id : Config.EXTERNAL_MOD_IDS.get()) {
            if (ModList.get().isLoaded(id)) return true;
        }
        return false;
    }

    private static boolean fromExternal(ResourceLocation rl) {
        for (String id : Config.EXTERNAL_MOD_IDS.get()) {
            if (id.equals(rl.getNamespace()) && ModList.get().isLoaded(id)) return true;
        }
        return false;
    }

    /** @return indice gemma 0..5 oppure -1 se l'item non e' una gemma. */
    public static int gemIndex(ItemStack stack) {
        if (stack.isEmpty()) return -1;
        ResourceLocation rl = ForgeRegistries.ITEMS.getKey(stack.getItem());
        if (rl == null) return -1;
        String path = rl.getPath();
        if (rl.getNamespace().equals(IronManMod.MODID)) {
            for (int i = 0; i < KEYS.length; i++) {
                if (path.equals("gem_" + KEYS[i])) return i;
            }
            return -1;
        }
        if (fromExternal(rl) && (path.contains("gem") || path.contains("stone") || path.contains("infinity"))) {
            for (int i = 0; i < KEYS.length; i++) {
                if (path.contains(KEYS[i])) return i;
            }
        }
        return -1;
    }

    /** Lo slot "Nucleo" accetta qualsiasi item della mod esterna che non sia una gemma (es. il Nucleo / il Guanto). */
    public static boolean isCore(ItemStack stack) {
        if (stack.isEmpty()) return false;
        ResourceLocation rl = ForgeRegistries.ITEMS.getKey(stack.getItem());
        return rl != null && fromExternal(rl) && gemIndex(stack) < 0;
    }
}
