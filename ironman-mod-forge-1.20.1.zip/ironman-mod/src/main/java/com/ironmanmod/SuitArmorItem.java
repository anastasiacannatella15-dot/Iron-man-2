package com.ironmanmod;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;

import java.util.function.Consumer;

/** Pezzo di armatura nanotech: non si rompe, non si incanta, non si può togliere a mano. */
public class SuitArmorItem extends ArmorItem {
    public final SuitMark mark;

    public SuitArmorItem(SuitMark mark, ArmorItem.Type type) {
        super(mark, type, new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant());
        this.mark = mark;
    }

    @Override
    public <T extends LivingEntity> int damageItem(ItemStack stack, int amount, T entity, Consumer<T> onBroken) {
        return 0;
    }

    @Override
    public boolean isEnchantable(ItemStack stack) {
        return false;
    }

    @Override
    public boolean isBookEnchantable(ItemStack stack, ItemStack book) {
        return false;
    }
}
