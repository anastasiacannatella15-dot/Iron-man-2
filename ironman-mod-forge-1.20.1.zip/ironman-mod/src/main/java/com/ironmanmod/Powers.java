package com.ironmanmod;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Repulsori, Unibeam, micro-missili e teletrasporto (Gemma dello Spazio). */
public final class Powers {
    private static final DustParticleOptions BLUE = new DustParticleOptions(new Vector3f(0.3f, 0.85f, 1f), 1.3f);
    private static final DustParticleOptions BIG = new DustParticleOptions(new Vector3f(0.6f, 0.95f, 1f), 2.4f);

    private Powers() {
    }

    private record Trace(Vec3 end, List<LivingEntity> hits) {
    }

    private static Trace trace(ServerPlayer p, double range, boolean pierce) {
        Level lvl = p.level();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 end = eye.add(look.scale(range));
        BlockHitResult bh = lvl.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (bh.getType() != HitResult.Type.MISS) end = bh.getLocation();
        final Vec3 fEnd = end;

        AABB box = new AABB(eye, fEnd).inflate(1.5);
        List<LivingEntity> cand = lvl.getEntitiesOfClass(LivingEntity.class, box,
                e -> e != p && e.isAlive() && !e.isSpectator());
        Map<LivingEntity, Double> dist = new HashMap<>();
        List<LivingEntity> hits = new ArrayList<>();
        for (LivingEntity e : cand) {
            Optional<Vec3> h = e.getBoundingBox().inflate(0.3).clip(eye, fEnd);
            if (h.isPresent()) {
                dist.put(e, eye.distanceToSqr(h.get()));
                hits.add(e);
            }
        }
        hits.sort(Comparator.comparingDouble((LivingEntity e) -> dist.get(e)));
        if (!pierce && hits.size() > 1) hits = new ArrayList<>(hits.subList(0, 1));
        if (!pierce && !hits.isEmpty()) end = eye.add(look.scale(Math.sqrt(dist.get(hits.get(0)))));
        return new Trace(end, hits);
    }

    private static void beam(ServerLevel lvl, Vec3 from, Vec3 to, boolean big) {
        Vec3 d = to.subtract(from);
        double len = d.length();
        if (len < 0.5) return;
        Vec3 dir = d.scale(1.0 / len);
        double step = big ? 0.35 : 0.9;
        int n = 0;
        for (double s = 0.6; s < len; s += step, n++) {
            Vec3 pt = from.add(dir.scale(s));
            lvl.sendParticles(big ? BIG : BLUE, pt.x, pt.y, pt.z, 1, 0.03, 0.03, 0.03, 0);
            if (big && n % 3 == 0) lvl.sendParticles(ParticleTypes.END_ROD, pt.x, pt.y, pt.z, 1, 0.1, 0.1, 0.1, 0.01);
        }
    }

    private static void hit(ServerPlayer p, LivingEntity e, float dmg, boolean fire, boolean soul) {
        if (e.hurt(p.damageSources().playerAttack(p), dmg)) {
            Vec3 d = e.position().subtract(p.position());
            d = new Vec3(d.x, 0, d.z).normalize();
            e.push(d.x * 0.9, 0.25, d.z * 0.9);
            e.hurtMarked = true;
            if (soul) p.heal(1.5f); // Gemma dell'Anima
        }
        if (fire) e.setSecondsOnFire(6);
    }

    // ------------------------------------------------------------------ repulsore

    public static void repulsor(ServerPlayer p) {
        SuitMark m = SuitData.activeMark(p);
        if (m == null || !SuitData.ready(p, "rep")) return;
        if (!SuitData.useEnergy(p, 80)) {
            SuitData.msg(p, "msg.ironmanmod.no_energy");
            return;
        }
        SuitData.setCooldown(p, "rep", 10);
        ServerLevel lvl = p.serverLevel();
        float dmg = m.repulsorDamage * SuitData.damageMult(p);
        boolean soul = SuitData.gems(p)[3];

        Trace tr = trace(p, 40, false);
        Vec3 from = p.getEyePosition().add(0, -0.35, 0).add(p.getLookAngle().scale(0.5));
        beam(lvl, from, tr.end(), false);
        for (LivingEntity e : tr.hits()) hit(p, e, dmg, false, soul);

        lvl.sendParticles(ParticleTypes.FLASH, tr.end().x, tr.end().y, tr.end().z, 1, 0, 0, 0, 0);
        lvl.sendParticles(BIG, tr.end().x, tr.end().y, tr.end().z, 6, 0.25, 0.25, 0.25, 0.02);
        lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.0f, 2.0f);
    }

    // ------------------------------------------------------------------ unibeam (Mark 50 e 85)

    public static void unibeam(ServerPlayer p) {
        SuitMark m = SuitData.activeMark(p);
        if (m == null) return;
        if (m.unibeamDamage <= 0f) {
            SuitData.msg(p, "msg.ironmanmod.no_unibeam");
            return;
        }
        if (!SuitData.ready(p, "uni")) return;
        if (!SuitData.useEnergy(p, 1500)) {
            SuitData.msg(p, "msg.ironmanmod.no_energy");
            return;
        }
        SuitData.setCooldown(p, "uni", 60);
        ServerLevel lvl = p.serverLevel();
        float dmg = m.unibeamDamage * SuitData.damageMult(p);
        boolean soul = SuitData.gems(p)[3];

        Trace tr = trace(p, 64, true);
        Vec3 from = p.position().add(0, 1.2, 0).add(p.getLookAngle().scale(0.5)); // dal reattore sul petto
        beam(lvl, from, tr.end(), true);
        for (LivingEntity e : tr.hits()) hit(p, e, dmg, true, soul);

        lvl.sendParticles(ParticleTypes.FLASH, tr.end().x, tr.end().y, tr.end().z, 1, 0, 0, 0, 0);
        lvl.sendParticles(ParticleTypes.EXPLOSION, tr.end().x, tr.end().y, tr.end().z, 2, 0.4, 0.4, 0.4, 0);
        lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 1.2f, 1.2f);
    }

    // ------------------------------------------------------------------ micro-missili

    public static void missiles(ServerPlayer p) {
        SuitMark m = SuitData.activeMark(p);
        if (m == null || !SuitData.ready(p, "mis")) return;
        if (!SuitData.useEnergy(p, 500)) {
            SuitData.msg(p, "msg.ironmanmod.no_energy");
            return;
        }
        SuitData.setCooldown(p, "mis", 100);
        ServerLevel lvl = p.serverLevel();

        List<LivingEntity> targets = new ArrayList<>(lvl.getEntitiesOfClass(LivingEntity.class,
                p.getBoundingBox().inflate(28), e -> e instanceof Enemy && e.isAlive() && e != p && p.hasLineOfSight(e)));
        targets.sort(Comparator.comparingDouble((LivingEntity e) -> e.distanceToSqr(p)));

        Vec3 shoulder = p.position().add(0, 1.6, 0);
        int count = Math.min(m.missiles, targets.size());
        for (int i = 0; i < count; i++) {
            LivingEntity t = targets.get(i);
            Vec3 pos = t.position().add(0, t.getBbHeight() * 0.5, 0);
            beam(lvl, shoulder, pos, false);
            hit(p, t, 6f * SuitData.damageMult(p), false, false);
            lvl.explode(p, pos.x, pos.y, pos.z, 1.6f, Level.ExplosionInteraction.NONE);
        }
        if (count == 0) {
            Trace tr = trace(p, 30, false);
            Vec3 end = tr.end();
            if (end.distanceTo(p.position()) > 4) {
                beam(lvl, shoulder, end, false);
                lvl.explode(p, end.x, end.y, end.z, 1.6f, Level.ExplosionInteraction.NONE);
            }
        }
        lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 1.0f, 0.8f);
    }

    // ------------------------------------------------------------------ Gemma dello Spazio

    public static void spaceJump(ServerPlayer p) {
        SuitMark m = SuitData.activeMark(p);
        if (m == null) return;
        if (!SuitData.gems(p)[1]) {
            SuitData.msg(p, "msg.ironmanmod.need_space");
            return;
        }
        if (!SuitData.ready(p, "spc")) return;
        if (!SuitData.useEnergy(p, 400)) {
            SuitData.msg(p, "msg.ironmanmod.no_energy");
            return;
        }
        SuitData.setCooldown(p, "spc", 40);
        ServerLevel lvl = p.serverLevel();

        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 end = eye.add(look.scale(50));
        BlockHitResult bh = lvl.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 dest = bh.getType() != HitResult.Type.MISS ? bh.getLocation().subtract(look.scale(0.8)) : end;

        lvl.sendParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 40, 0.4, 0.8, 0.4, 0.3);
        p.teleportTo(dest.x, dest.y - 1.0, dest.z);
        lvl.sendParticles(ParticleTypes.PORTAL, dest.x, dest.y, dest.z, 40, 0.4, 0.8, 0.4, 0.3);
        lvl.playSound(null, dest.x, dest.y, dest.z, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0f, 1.0f);
    }
}
