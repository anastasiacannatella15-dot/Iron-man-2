# Iron Man Mod — Mark 42 / Mark 50 / Mark 85

Minecraft **1.20.1** · Forge **47.3.0** · Java **17**

## Come ottenere il .jar

**Metodo consigliato (con il wrapper Gradle ufficiale):**
1. Scarica il "Mdk" di Forge 1.20.1 (47.3.0) da https://files.minecraftforge.net e scompattalo.
2. Copia dentro la sua cartella il mio `src/` e il mio `build.gradle` (sovrascrivi quelli dell'MDK).
3. Apri un terminale nella cartella ed esegui:
   - Windows: `gradlew build`
   - Linux/Mac: `./gradlew build`
4. Il file finito è in `build/libs/ironmanmod-1.0.0.jar` → mettilo nella cartella `mods` di Minecraft.

**Alternativa:** con JDK 17 e Gradle 8.1.x installati, esegui `gradle build` direttamente in questa cartella.

## Come si gioca

1. **Craft del Reattore Arc** (serve per trasformarsi, un reattore per ogni modello):
   - Mark 42: ferro + oro + blocco di redstone (`IGI / GRG / IGI`, R = blocco di redstone)
   - Mark 50: diamanti + oro + Reattore Mark 42 al centro (`DGD / GRG / DGD`)
   - Mark 85: lingotti di netherite + stelle del Nether + blocchi di diamante + Reattore Mark 50 al centro (`NSN / DRD / NSN`)
   - Tutti sono anche nella tab creativa "Iron Man". Con `requireReactor=false` nel config non servono.
2. **Tasti** (modificabili in Opzioni → Controlli → Iron Man):

| Tasto | Azione |
|-------|--------|
| **G** | Trasformati / rimuovi l'armatura (3 secondi di nanotech) |
| **H** | Cambia modello (42 → 50 → 85) |
| **R** | Repulsore |
| **V** | Unibeam (solo Mark 50 e 85) |
| **B** | Micro-missili (4 / 6 / 8 bersagli) |
| **X** | Teletrasporto (serve la Gemma dello Spazio, Mark 85) |
| **K** | Pannello Gemme (Mark 85) |

3. In alto a sinistra c'è il bottone con il tasto di trasformazione e la barra di avanzamento; a armatura attiva mostra energia, altitudine e velocità.
4. **Volo**: doppio salto per volare (come in creativa). Tieni **Sprint + W** mentre voli per il volo supersonico nella direzione in cui guardi.
5. L'energia si consuma volando e sparando, e si ricarica a terra. Senza energia non si vola.

## Differenze tra i modelli

| | Mark 42 | Mark 50 | Mark 85 |
|---|---|---|---|
| Energia | 2000 | 4500 | 9000 |
| Repulsore | 8 | 11 | 14 |
| Unibeam | no | 28 | 40 |
| Micro-missili | 4 | 6 | 8 |
| Scudo nanotech | 0% | 20% | 35% |
| Gemme dell'Infinito | no | no | sì |

## Gemme dell'Infinito (Mark 85)

Premi **K** con la Mark 85 indossata. Il pannello ha 1 slot **Nucleo** + 6 slot **Gemme**.
In alto a destra sullo schermo compare lo slot Nucleo con le gemme inserite.

- Potere: danni ×1.6 e Forza · Spazio: teletrasporto (X) · Realtà: rigenerazione
- Anima: ti curi colpendo · Tempo: velocità e cooldown dimezzati · Mente: evidenzia i mostri vicini
- Con tutte e 6 le gemme: danni ×2.5

Le gemme di questa mod si craftano con una stella del Nether circondata da 8 materiali
(ametista = Potere, lapislazzuli = Spazio, redstone = Realtà, blaze powder = Anima, smeraldo = Tempo, polvere di glowstone = Mente).

### Compatibilità con "Pugmeowla's Infinity Stone Core"
Se hai quella mod installata, lo slot **Nucleo** accetta i suoi item e le sue gemme (il cui nome contiene
power/space/reality/soul/time/mind) valgono come gemme nel pannello.
L'ID di quella mod non l'ho potuto verificare: se non viene riconosciuta, apri
`config/ironmanmod-common.toml` e aggiungi il suo ID alla lista `externalModIds`.

## Morte
Se muori senza keepInventory, l'armatura nanotech sparisce e droppano la tua armatura originale e le gemme.
